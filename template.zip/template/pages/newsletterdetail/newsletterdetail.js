var app = getApp(),
  $ = require("../../utils/util.js"),
  WxParse = require("../../wxParse/wxParse.js"),
  activityapi = require("../../api/activityAPI.js");

Page({
  data: {
    dataList: [],
    Id: 0,
    flag: !0,
    activitydetail: [],
  },
  onLoad: function (e) {
    this.setData({
      Id: e.id
    }),
    $.isNull(app.globalData.UserInfo) ? app.GetUserInfo(function () {
    this.GetNewsletter();
    }, e.uid) : this.GetNewsletter();
    try {
      var t = wx.getSystemInfoSync();
      this.setData({
        windowHeight: t.windowHeight
      })
    } catch (n) {
      console.log(" Do something when catch error")
    }
    // this.GetNewsletterList(), this.GetNewsletterCategory()
  },
  
  GetNewsletter: function () {
   
    var e = {
      id: this.data.Id,
      openId: app.globalData.UserInfo.WeiXinOpenId
    },

      t = this;
    $.xsr($.makeUrl(activityapi.GetNewsletter, e),
      function (e) {
        console.log(e),
          $.isNull(e.dataList) ? t.setData({
            flag: !1
          }) : (t.setData({
            dataList: e.dataList,
            markers: [{
              iconPath: "/assets/others.png",
              id: 0,
              latitude: e.dataList.lat,
              longitude: e.dataList.lon,
              width: 50,
              height: 50
            }],
            video: e.dataList.video,
          }), t.data.Content || WxParse.wxParse("activitydetail", "html", e.dataList.Content, t)),
          wx.setNavigationBarTitle({
            title: t.data.dataList.Title
          })
      })
  },
  /**
   * 用户点击分享按钮或右上角分享
   */
  onShareAppMessage: function (res) {
    var that = this;
    return {
      title: that.data.dataList.Title,
      path: '/pages/newsletterdetail/newsletterdetail?id=' + that.data.Id,
      success: function (res) {
        // 转发成功
      },
      fail: function (res) {
        // 转发失败
      }
    }
  },
  onHide() {
    var dataid = this.data.Id
    app.DataStatistic(dataid);
  },

  onUnload() {
    var dataid = this.data.Id
    app.DataStatistic(dataid);
  }
});