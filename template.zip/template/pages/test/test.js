//index.js
//获取应用实例
var app = getApp();
var calendarSignData;
var date;
var calendarSignDay;
var app = getApp(),

  $ = require("../../utils/util.js"),
  api = require("../../api/indexAPI.js"),
  notice = require("../../utils/notice.js"),
  WxParse = require("../../wxParse/wxParse.js");

Page({
  //事件处理函数

  getDataList(that) {

    var vdata = {
      openId: app.globalData.UserInfo.WeiXinOpenId
    };

    $.xsr($.makeUrl(api.GetIndexData, vdata),
      function (res) {
        console.log(res.dataList);
        var _data = res.dataList.indexArray;
        for (var i = 0; i < _data.length; i++) {
          if (_data[i].name == 'form') {
            for (var j = 0; j < _data[i].dataList.length; j++) {
              var formItems = JSON.parse(_data[i].dataList[j].formItems)
              _data[i].dataList[j].formItems = formItems;
            }
            var formItem = formItems.length
          }
        }
        that.setData({
          indexArray: _data,
          formItemLength: formItem ? formItem : 0
        }),

          wx.setStorageSync('copyright', res.dataList.copyright)
        var copyright = wx.getStorageSync('copyright')
        that.setData({
          copyright: copyright,
          sharName: res.dataList.ShopName
        })

        wx.setStorageSync('companytel', res.dataList.companytel)
        var companytel = wx.getStorageSync('companytel')
        that.setData({
          companytel: companytel,
          flag: !1
        })

        wx.setNavigationBarTitle({
          title: res.dataList.ShopName
        })
      })
  },

  calendarSign: function () {
    calendarSignData[date] = date;
    console.log(calendarSignData);
    calendarSignDay = calendarSignDay + 1;
    wx.setStorageSync("calendarSignData", calendarSignData);
    wx.setStorageSync("calendarSignDay", calendarSignDay);

    wx.showToast({
      title: '签到成功',
      icon: 'success',
      duration: 2000
    })
    this.setData({

      calendarSignData: calendarSignData,
      calendarSignDay: calendarSignDay
    })
  },
  
  onLoad: function (e) {
    var that=this;
    app.GetUserInfo(function () {
      that.getDataList(that);
    },
      e.uid, e.sid), notice.addNotification("RefreshProduct", that.RefreshProduct, that);

    var mydate = new Date();
    var year = mydate.getFullYear();
    var month = mydate.getMonth() + 1;
    date = mydate.getDate();
    console.log("date" + date)
    var day = mydate.getDay();
    console.log(day)
    var nbsp = 7 - ((date - day) % 7);
    console.log("nbsp" + nbsp);
    var monthDaySize;
    if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
      monthDaySize = 31;
    } else if (month == 4 || month == 6 || month == 9 || month == 11) {
      monthDaySize = 30;
    } else if (month == 2) {
      // 计算是否是闰年,如果是二月份则是29天
      if ((year - 2000) % 4 == 0) {
        monthDaySize = 29;
      } else {
        monthDaySize = 28;
      }
    };
    // 判断是否签到过
    if (wx.getStorageSync("calendarSignData") == null || wx.getStorageSync("calendarSignData") == '') {
      wx.setStorageSync("calendarSignData", new Array(monthDaySize));
    };
    if (wx.getStorageSync("calendarSignDay") == null || wx.getStorageSync("calendarSignDay") == '') {
      wx.setStorageSync("calendarSignDay", 0);
    }
    calendarSignData = wx.getStorageSync("calendarSignData")
    calendarSignDay = wx.getStorageSync("calendarSignDay")
    console.log(calendarSignData);
    console.log(calendarSignDay)
    this.setData({
      year: year,
      month: month,
      nbsp: nbsp,
      monthDaySize: monthDaySize,
      date: date,
      calendarSignData: calendarSignData,
      calendarSignDay: calendarSignDay
    })
  }
})

