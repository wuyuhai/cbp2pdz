var app = getApp(),
  $ = require("../../utils/util.js"),
  api = require("../../api/indexAPI.js"),
  notice = require("../../utils/notice.js"),
  WxParse = require("../../wxParse/wxParse.js");
Page({
  onReady: function (e) {
    this.audioCtx = wx.createAudioContext('myaudio');
  },
  data: {
    indexArray: [],
    platform: '',
    clickpayflag: false,
    audioSrc: 'https://chuangbeikeji.com/assets/images/design/style/music/music.png',
    audioicon: '../../assets/top3.png',
    show_: false,
    selectval: '',
    options_index: {},
    formItemLength: 0,
    menuData: [],
    imgheights: [],
    flag:!0
  },
  formSubmit: function (e) {
    var that=this;
    var data = e.detail.value;
    var formId = data.formId;
    var dataJson = {};
    for (var i = 0; i < this.data.formItemLength; i++) {
      dataJson[data["key" + i]] = data['value' + i]
    }
    var formData = {
      formId: formId,
      Wechat: this.data.wechat_id,
      openId: app.globalData.UserInfo.WeiXinOpenId,
      data: JSON.stringify(dataJson)
    }
    $.xsr($.makeUrl(api.userInfoSubmitForm, formData),
      function (data) {
        var str="提交成功"
        data.errcode == 0 ?that.openAlert(str): that.openAlert(data.errmsg);
      })
  },
  openAlert: function (str) {
    wx.showModal({
      title:"操作提示",
      content: str,
      showCancel: false,
      success: function (res) {
        if (res.confirm) {
          
        }
      }
    });
  },
  clicpayphone: function (e) {
    var phones = e.currentTarget.dataset.phones;
    if (phones) {
      wx.makePhoneCall({
        phoneNumber: phones//仅为示例
      })
    } else {
      wx.showToast({
        title: '电话为空',
      })
    }
  },
  clickpay: function () {//播放音乐
    if (this.data.clickpayflag) {
      this.setData({
        clickpayflag: !this.data.clickpayflag,
        audioicon: '../../assets/top3.png'
      });
      this.audioCtx.play();
    } else {
      this.audioCtx.seek(0)
      this.audioCtx.pause();
      this.setData({
        clickpayflag: !this.data.clickpayflag,
        audioicon: '../../assets/top2.png'
      })
    }
    console.log(this.data.audioicon);
  },
  clicktoogle: function (e) {
    var index = e.currentTarget.dataset.index;
    this.data.options_index[index] = e.detail.value;
    this.setData({
      options_index: this.data.options_index
    });
  },

  onLoad: function (e) {

    var that = this;
    try {
      var e = wx.getSystemInfoSync();
      this.setData({
        platform: e.platform
      })
    } catch (t) {
      console.log(t)
    }

    app.GetUserInfo(function () {
      that.initData();
      app.getMenuData(app.globalData.menuData);
      that.getDataList(that);
    },
      e.uid, e.sid), notice.addNotification("RefreshProduct", that.RefreshProduct, that);
  },

  initData: function () {
    var that = this;
    if (app.globalData.VendorInfo) {
      wx.setNavigationBarTitle({
        title: app.globalData.VendorInfo.ShopName
      })
    }
  },
  onShareAppMessage: function () {
    return {
      title:$.isNull(app.globalData.VendorInfo.ShopName)?(this.data.sharName):app.globalData.VendorInfo.ShopName,
      desc: app.globalData.VendorInfo.VendorInfo,
      path: "/pages/index/index?uid=" + app.globalData.UserInfo.Id
    }
  },

  getDataList(that) {
    var vdata = {
      openId: app.globalData.UserInfo.WeiXinOpenId
    };
    $.xsr($.makeUrl(api.GetIndexData, vdata),
      function (res) {
        console.log(res.dataList);
        var _data = res.dataList.indexArray;
        for (var i = 0; i < _data.length; i++) {
          if (_data[i].name == 'form') {
            for (var j = 0; j < _data[i].dataList.length; j++) {
              var formItems = JSON.parse(_data[i].dataList[j].formItems)
              _data[i].dataList[j].formItems = formItems;
            }
            var formItem = formItems.length
          }
        }
        that.setData({
          indexArray: _data,
          formItemLength: formItem ? formItem : 0
        }),

      wx.setStorageSync('copyright', res.dataList.copyright)
        var copyright = wx.getStorageSync('copyright')
        that.setData({
          copyright: copyright,
          sharName: res.dataList.ShopName
        })

        wx.setStorageSync('companytel', res.dataList.companytel)
        var companytel = wx.getStorageSync('companytel')
        that.setData({
          companytel: companytel,
          flag:!1
        })

        wx.setNavigationBarTitle({
          title: res.dataList.ShopName
        })
      })
  },
  
  onShow(){
    this.audioCtx = wx.createAudioContext('myaudio');
    this.audioCtx.play();
  },
  
  onHide(){
    app.DataStatistic(0);
    this.audioCtx.seek(0);
    this.audioCtx.pause();
  },

  outertouch: function () { this.setData({ flag: !0 }) }

});