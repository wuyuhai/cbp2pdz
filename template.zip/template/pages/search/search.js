var $ = require("../../utils/util.js");
Page({
    data: {val: ""}, onShow: function () {
    }, startinput: function (e) {
        this.setData({val: e.detail.value})
    }, search: function () {
        var e = this;
        $.isNull(e.data.val) ? $.confirm("请输入你要搜索的关键词!") : wx.redirectTo({
            url: "/pages/search_product/search_product?pname=" + e.data.val,
            fail: function (e) {
                console.log("跳转失败!", e)
            }
        })
    }
});