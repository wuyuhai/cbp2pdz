var app = getApp(),
  $ = require("../../utils/util.js"),
  userapi = require("../../api/userAPI.js");
Page({
  data: {
    tapindex: 1,
    pageindex: 1,
    ChangeType: -1,
    ispage: !0,
    flag: !0,
    CaseDetailList: []


  },onLoad:function(e){

    this.setData({
      ChangeType: e.ChangeType,
      tapindex:e.tabIndex
    })
  },

  onShow: function () {

    this.setData({
      CaseDetailList: []
    }), this.InitData()
  },
  
  InitData: function () {
    var e = {
      type: this.data.ChangeType,
      openId: app.globalData.UserInfo.WeiXinOpenId,
      page: this.data.pageindex
    },
     t = this;
     
    $.xsr($.makeUrl(userapi.VipGetBalanceLog, e), function (e) {

      console.log(e)

      if(e.errcode == 0){

        e.dataList != null && e.errcode != 1 ? e.dataList.length < 10 ? t.setData({

          CaseDetailList: t.data.CaseDetailList.concat(e.dataList),
          flag: !1,
          ispage: !1

        }) : t.setData({

          CaseDetailList: t.data.CaseDetailList.concat(e.dataList)

        }) : t.setData({
          flag: !1,
          ispage: !1
        })
        

      }else{
        app.wuiAlert("错误提示", e.errmsg, '确认', '');
      } 
    })
  },
  
  scrollbottom: function () {

    if (this.data.flag) {

      var e = this;
      clearTimeout(t);

      var t = setTimeout(function () {
        e.setData({
          pageindex: parseInt(e.data.pageindex) + 1
        }), e.InitData()
      }, 500)

    }
  },
  allTypes: function () {//全部
    this.setData({
      tapindex: 1,
      pageindex: 1,
      ispage: !0,
      flag: !0,
      ChangeType:-1,
      CaseDetailList: []
    }), this.InitData()
  },
  expenditure: function () {//支出
    this.setData({
      tapindex: 2,
      pageindex: 1,
      ispage: !0,
      flag: !0,
      ChangeType:0,
      CaseDetailList: []
    }), this.InitData()
  },
  income: function () {//收入
    this.setData({
      tapindex: 3,
      pageindex: 1,
      ispage: !0,
      ChangeType: 2,
      flag: !0,
      CaseDetailList: []
    }), this.InitData()
  },
  Recharge: function () {//充值
    this.setData({
      tapindex: 4,
      pageindex: 1,
      ispage: !0,
      ChangeType:1,
      flag: !0,
      CaseDetailList: []
    }), this.InitData()
  }
});