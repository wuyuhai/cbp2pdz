var app = getApp(),
  $ = require("../../utils/util.js");
Page({
  data: {
    UserInfo: ""
  },
  onLoad: function () {
    
    var copyright = wx.getStorageSync('copyright')
      this.setData({
        UserInfo: app.globalData.UserInfo,
        copyright: copyright
      })
  },
  selectAddress: function () {
    var e = this;
    wx.chooseAddress({
      success: function (e) {
        $.gopage("/pages/shopaddress/shopaddress")
      },
      fail: function (e) {
        $.gopage("/pages/shopaddress/shopaddress")
      }
    })
  }
});