function getNowFormatDate() {

  var e = new Date()
    , t = "-"
    , n = e.getMonth() + 1
    , r = e.getDate();
  n >= 1 && n <= 9 && (n = "0" + n),
    r >= 0 && r <= 9 && (r = "0" + r);
  var i = e.getFullYear() + t + n + t + r;
  return i;

}

var app = getApp(),
  $ = require("../../utils/util.js"),
  api = require("../../api/productAPI.js"),
  cartapi = require("../../api/cartAPI.js"),
  WxParse = require("../../wxParse/wxParse.js"),
  userapi = require("../../api/userAPI.js"),
  notice = require("../../utils/notice.js"),
  intervalDate;

Page({

  data: {
    selectsp: 0,
    selectct: 0,
    proId: 0,
    CommentImgList: [],
    splist: [],
    splistStr: [],
    numval: 1,
    stock: 1,
    inputval: 1,
    skuid: 0,
    selectimg: "",
    pname: "",
    desc: "",
    isCollection: !1,
    MEID: 0,
    eventId: 0,
    isdata: !0,
    tapindex: 1,
    ProductInfo: {},
    Coupons: [],
    isCancelSuccess: !0,
    isCancel: !0,
    CouponAmount: 0,
    IsNewUser: 0,
    flag: !1,
    flag1: !1,
    selectcoupon: 0,
    selectctfag: 0,
    ispage: !1,
    CenterCoupon: [],
  },
  onLoad: function onLoad(e) {

    this.Countdown(1526473821)

    var t = this;
    t.InitData(e);

  },

  InitData: function InitData(e) {
    var t = this;
    this.setData({
      proId: e.id,
      splistStr: [],
      eventId: e.MEId ? e.MEId : ""
    }),
      $.isNull(app.globalData.UserInfo) ? app.GetUserInfo(function () {
        t.InitProduct();
      }, e.uid) : t.InitProduct();
  },
  InitProduct: function InitProduct() {
    var e = this
      , t = {
        openId: app.globalData.UserInfo.WeiXinOpenId,
        proId: e.data.proId,
        eventId: e.data.eventId
      };
    $.xsr($.makeUrl(api.GetProductInfo, t), function (t) {
      t.dataList[0].SellingPoints
      if (t.errcode > 0)
        e.setData({
          isdata: !1
        });
      else {
        if (t.dataList[0].SpecLst.length > 0)
          for (var n in t.dataList[0].SpecLst) {
            for (var r in t.dataList[0].SpecLst[n].svLst) {
              if (t.dataList[0].SpecLst[n].svLst[r].IsChecked) {
                t.dataList[0].SpecLst[n].ckid = t.dataList[0].SpecLst[n].svLst[r].Id,
                  e.data.splist.push(t.dataList[0].SpecLst[n].svLst[r].Id),
                  e.data.splistStr.push(t.dataList[0].SpecLst[n].svLst[r].Name),
                  e.setData({
                    selectimg: t.dataList[0].SpecLst[n].svLst[r].imagePath
                  });
              } else {
                e.setData({
                  selectimg: t.dataList[0].ProductPic
                });
              }
            }
          }
        wx.setNavigationBarTitle({
          title: t.dataList[0].SalesName
        }),
          e.setData({
            ProductInfo: t.dataList[0],
            isCollection: t.dataList[0].isCollection > 0 ? !0 : !1,
            skuid: t.dataList[0].ProductSKU_Id,
            desc: t.dataList[0].SellingPoints,
            pname: t.dataList[0].ProductName,
            stock: t.dataList[0].Stock
          }),
          WxParse.wxParse("pinfo", "html", t.dataList[0].Describe, e),
          WxParse.wxParse("pinfo2", "html", t.dataList[0].ProductParameters, e);
      }
      var strs = [];
      e.data.ProductInfo.SellingPoints ? e.setData({ labelText: e.data.ProductInfo.SellingPoints.split("，") }) : "";
    });
    console.log(e.data.ProductInfo)
  },
  ckselectsp: function ckselectsp(e) {
    this.setData({
      change: e.currentTarget.offsetLeft,
      selectsp: 1,
      selectct: 1,
      flag: !0,
      flag1: !1
    });
  },
  ckselectsp1: function ckselectsp1(e) {
    this.setData({
      change: e.currentTarget.offsetLeft,
      selectsp: 1,
      selectct: 1,
      flag1: !0,
      flag: !1
    });
  },
  closesp: function closesp() {
    var e = this;
    e.setData({
      selectct: 0,
      flag: !1
    }),
      setTimeout(function () {
        e.setData({
          selectsp: 0
        });
      }, 1e3);
  },

  ckselectcoupon: function (e) {
    var that = this;
    that.setData({
      selectctfag: 1,
      selectcoupon: 1
    });
    var openid = {
      openId: app.globalData.UserInfo.WeiXinOpenId
    };

    $.xsr($.makeUrl(userapi.GetVendorCoupons, openid),
      function (e) {
        console.log(e.dataList)
        e.dataList != null && e.errcode != 1 ? that.setData({
          CenterCoupon: e.dataList,
          ispage: !0
        }) : that.setData({
          ispage: !0
        })
      })
  },
  getUserReceiveCoupon: function () {
    var e = {
      openId: app.globalData.UserInfo.WeiXinOpenId,
      CouponIds: this.data.Id,
      Code: this.data.Code,
      IsNewUser: 0
    },
      t = this;
    $.xsr($.makeUrl(userapi.UserReceiveCoupon, e),
      function (e) {
        !$.isNull(e.dataList) && e.errcode == 0 ? (t.setData({
          flag: !1,
          Coupons: e.dataList,

        }), t.ckselectcoupon()) : $.alert(e.errmsg)
      })
  },

  closecoupon: function () {
    var that = this;
    that.setData({
      selectctfag: 0,
    }),
      setTimeout(function () {
        that.setData({
          selectcoupon: 0
        });
      }, 1e3);

  },
  click_lingqu: function (e) {

    if (e.currentTarget.dataset.isreceive == -1) return;
    this.setData({
      Id: e.currentTarget.dataset.id
    }),

      this.getUserReceiveCoupon();
  },
  selectsp: function selectsp(e) {
    var t = {
      spid: e.target.dataset.spid,
      ckid: e.target.dataset.ckid
    }
      , n = []
      , r = this.data.splist;
    for (var i in r) {
      r[i] == t.ckid ? n.push(t.spid) : n.push(r[i]);
    }
    this.setData({
      splist: n,
      splistStr: []
    });
    var s = {
      proId: this.data.proId,
      Spec: this.data.splist.join(","),
      eventId: this.data.eventId
    }
      , o = this;
    $.xsr($.makeUrl(api.GetProductlistSpc, s), function (t) {
      for (var n in t.dataList[0].SpecLst) {
        for (var r in t.dataList[0].SpecLst[n].svLst) {
          t.dataList[0].SpecLst[n].svLst[r].IsChecked && (t.dataList[0].SpecLst[n].ckid = t.dataList[0].SpecLst[n].svLst[r].Id,
            o.data.splist.push(t.dataList[0].SpecLst[n].svLst[r].Id),
            o.data.splistStr.push(t.dataList[0].SpecLst[n].svLst[r].Name)),
            t.dataList[0].SpecLst[n].svLst[r].Id == e.target.dataset.spid && o.setData({
              selectimg: t.dataList[0].SpecLst[n].svLst[r].imagePath
            });
        }
      }
      wx.setNavigationBarTitle({
        title: t.dataList[0].SalesName
      }),
        o.setData({
          ProductInfo: t.dataList[0],
          skuid: t.dataList[0].ProductSKU_Id,
          pname: t.dataList[0].ProductName,
          stock: t.dataList[0].Stock
        });
    });
  },
  sub: function sub() {
    this.unifiedNum(2);
  },
  add: function add() {
    this.unifiedNum(1);
  },
  writenum: function writenum(e) {
    this.setData({
      inputval: e.detail.value
    }),
      this.unifiedNum(3);
  },
  unifiedNum: function unifiedNum(e) {
    var t = {
      value: parseInt(this.data.numval),
      stock: parseInt(this.data.stock),
      inputval: parseInt(this.data.inputval)
    };
    if (t.stock <= 0) {
      $.alert("亲~商品没有库存啦！");
      return;
    }
    e == 1 ? t.value = t.value + 1 : e == 2 ? t.value = t.value - 1 : (t.value = t.inputval,
      this.setData({
        numval: t.inputval
      }));
    if (t.value > t.stock) {
      this.setData({
        numval: t.stock
      });
      return;
    }
    if (t.value <= 0) {
      this.setData({
        numval: 1
      });
      return;
    }
    this.setData({
      numval: t.value
    });
  },


  addCard: function addCard() {
    var e = {
      openId: app.globalData.UserInfo.WeiXinOpenId,
      proId: this.data.proId,
      proName: this.data.pname,
      Amount: this.data.numval,
      SKU_Id: this.data.skuid
    };
    if (this.data.stock <= 0) {
      $.alert("亲~商品没有库存啦！");
      return;
    }
    var t = this;
    $.xsr($.makeUrl(cartapi.AddCart, e), function (e) {
      e.errcode == 0 && (notice.postNotificationName("RefreshProduct", !0),
        $.alert("商品已经成功添加到购物车"),
        t.setData({
          numval: 1,
          inputval: 1
        }));
    }),
      t.setData({
        selectct: 0
      }),
      setTimeout(function () {
        t.setData({
          selectsp: 0
        });
      }, 1e3);
  },

  //收藏
  PDCollection: function PDCollection(e) {
    var t = this;
    if (this.data.isCollection) {
      var n = {
        openId: app.globalData.UserInfo.WeiXinOpenId,
        proId: e.currentTarget.dataset.id
      };
      $.xsr($.makeUrl(api.DelUserAttention, n), function (e) {
        t.setData({
          isCollection: !1
        }),
          $.alert("已取消收藏！");
      });
    } else {
      var n = {
        openId: app.globalData.UserInfo.WeiXinOpenId,
        proId: e.currentTarget.dataset.id
      };
      $.xsr($.makeUrl(api.AddAttention, n), function (e) {
        t.setData({
          isCollection: !0
        }),
          $.alert("已收藏！");
      });
    }
  },


  picDetail: function picDetail() {//tab切换
    this.setData({
      tapindex: 1
    });
  },

  spcParam: function spcParam() {//tab切换
    this.setData({
      tapindex: 2
    });
  },

  onShareAppMessage: function onShareAppMessage() {//分享商品
    return {
      title: this.data.pname,
      desc: this.data.desc,
      path: "/pages/goods/goods?id=" + this.data.proId + "&uid=" + app.globalData.UserInfo.Id
    };
  },


  buynow: function buynow(e) {
    var t = {
      Amount: this.data.numval,
      ProductId: this.data.proId,
      ProductSKU_Id: this.data.skuid,
      AddTime: getNowFormatDate(),
      orderType: 1,
      ProductSaleName: this.data.pname,
      SalePrice: this.data.ProductInfo.SalePrice,
      CostPrice: this.data.ProductInfo.CostPrice,
      MarketPrice: this.data.ProductInfo.MarketPrice,
      ProductPic: this.data.ProductInfo.ProductPic,
      openId: app.globalData.UserInfo.WeiXinOpenId,
      speStr: JSON.stringify(this.data.splistStr).replace("[", "").replace("]", "").replace(/\,/g, "  ").replace(/\"/g, "")
    };

    wx.navigateTo({
      url: "/pages/ordersubmit/ordersubmit?spid=" + JSON.stringify(t)
    }),

      this.setData({
        selectct: 0
      });
    var n = this;

    setTimeout(function () {
      n.setData({
        selectsp: 0
      });
    }, 1e3);

  },

  receivenow: function receivenow() {
    this.cancel(),
      this.userReceiveCoupon();
  },
  cancel: function cancel() {
    this.setData({
      isCancel: !1
    });
  },
  cancelsuccess: function cancelsuccess() {
    this.setData({
      isCancelSuccess: !0
    });
  },
  innertouch: function innertouch() { },
  userReceiveCoupon: function userReceiveCoupon() {
    var e = {
      openId: app.globalData.UserInfo.WeiXinOpenId,
      IsNewUser: this.data.IsNewUser
    }
      , t = this;
    $.xsr($.makeUrl(userapi.UserReceiveCoupon, e), function (e) {

      e.Code == 0 ? t.setData({
        isCancelSuccess: !1,
        Coupons: e.Info
      }) : $.alert(e.Msg);
    });
  },

  ImgTap: function ImgTap(e) {
    var t = this
      , n = [];
    for (var r in this.data.ProductInfo.Productcommentpic) {
      n.push(this.data.ProductInfo.Productcommentpic[r].Path);
    }
    var i = e.target.dataset.src;
    wx.previewImage({
      current: i,
      urls: n
    });
  },


  onHide() {//数据统计
    var dataid = this.data.proId
    app.DataStatistic(dataid);
  },
  onUnload() {//数据统计
    var dataid = this.data.proId
    app.DataStatistic(dataid);
  },
   Countdown: function (timestamp) {


     var that=this;

    setInterval(function () {

      timestamp-=1;

      var endTime = new Date(timestamp * 1000);
      var day = Math.floor(endTime / 1000 / 60 / 60 / 24%24);
      var hour = Math.floor(endTime / 1000 / 60 / 60 % 24);
      var min = Math.floor(endTime/ 1000 / 60 % 60);
      var sec = Math.floor(endTime/ 1000 % 60);

      if (hour < 10) {
        hour = "0" + hour;
      }

      if (min < 10) {
        min = "0" + min;
      }

      if (sec < 10) {
        sec = "0" + sec;
      }

      var countDownTime =day+"天 "+hour + ":" + min + ":"+sec;

      that.setData({
        countDownTime:countDownTime
      })
      

    }, 1000);
  }

});