// pages/member_system/member_system.js
var app = getApp(),
 $ = require("../../utils/util.js"),
  userapi = require("../../api/userAPI.js");
Page({
  data: {
    selectchecked:true,
    radioItems: [],
    selectradio:null,
    id:null
  },
  onLoad: function (options) {


  },
  onShow(){
    this.getPayMoney()
  },

  formsubmit:function(e){

    this.data.id = this.data.selectradio
    if (this.data.id){
      this.play(this.data.id);
    }else{
      app.wuiAlert("错误提示", '请选择你要充值的金额', '确认', '')
    }

  },
  radioChange: function (e) {
    var radioItems = this.data.radioItems;
    for (var i = 0, len = radioItems.length; i < len; ++i) {
      radioItems[i].checked = radioItems[i].id == e.detail.value;
    }
    this.setData({
      radioItems: radioItems,
      selectradio: e.detail.value
    });
  },
  onReady: function () {
  
  },
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },

  play:function(id){
    console.log(app.globalData.UserInfo.WeiXinOpenId)
    console.log(id)
    var s = this,
      vd = {
        openId: app.globalData.UserInfo.WeiXinOpenId,
        id:id
      };
    $.xsr($.makeUrl(userapi.VipRechargePay, vd), function (e) {
      if (e.errcode == 0) {
        wx.showModal({
          title: '支付提示',
          content: e.errmsg,
          confirmText: "确认",
          cancelText: "取消",
          showCancel:true ,
          success: function (res) {
            if (res.confirm) {
              wx.requestPayment({ 
                timeStamp: e.Info.timeStamp,
                nonceStr: e.Info.nonceStr,
                "package": e.Info.package,
                signType: "MD5",
                paySign: e.Info.paySign,
                success: function success(e) {
                  $.alert("支付成功！", function () {
                    setTimeout(function(){
                      $.backpage(1);
                    },1000)
                  });
                },
                fail: function fail(e) {
                  app.wuiAlert("支付提示", '您已取消支付！', '确认', '')
                }
              });
            } else {
              $.alert("取消成功");
            }
          }
        });

      } else {
        app.wuiAlert("充值提示",e.errmsg, '确认', '')
      }

    })

  },

  getPayMoney:function(){

    var s = this,
      vd = {
        openId: app.globalData.UserInfo.WeiXinOpenId
      };

    $.xsr($.makeUrl(userapi.getRechargeSet, vd), function (e) {
        console.log("充值资金遍历：", e), s.setData({
          radioItems: e.dataList
        })
    })
  }, 

  goReturn:function(){
    $.backpage(1)
  }

})