// function tabbarinit() {
//   return [
//     {
//       "current": 0,
//       "pagePath": "/pages/index/index",
//       "iconPath": "/assets/sy.png",
//       "selectedIconPath": "/assets/sy1.png",
//       "text": "主页"
//     },
//     {
//       "current": 0,
//       "pagePath": "/pages/main/main?PageId=402",
//       "iconPath": "/assets/zz.png",
//       "selectedIconPath": "/assets/zz1.png",
//       "text": "分类"
//     },
//     {
//       "current": 0,
//       "pagePath": "/pages/main/main?PageId=404",
//       "iconPath": "/assets/zs.png",
//       "selectedIconPath": "/assets/zs1.png",
//       "text": "知识"
//     },
//     {
//       "current": 0,
//       "pagePath": "/pages/main/main?PageId=401",
//       "iconPath": "/assets/sy.png",
//       "selectedIconPath": "/assets/sy.png",
//       "text": "我的"
//     }
//   ]
// }
// function tabbarmain(bindName = "tabdata", id, target) {
//   var that = target;
//   var bindData = {};
//   var otabbar = tabbarinit();
//   otabbar[id]['iconPath'] = otabbar[id]['selectedIconPath']//换当前的icon
//   otabbar[id]['current'] = 1;
//   bindData[bindName] = otabbar
//   that.setData({ bindData });
// }

// module.exports = {
//   tabbar: tabbarmain
// }