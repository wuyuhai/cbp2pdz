var app = getApp(),
$ = require("../../utils/util.js"),
  userapi = require("../../api/userAPI.js");
var calendarSignData = {};
var date;

var calendarSignDay = 0;

Page({


  calendarSign: function () {
    var that=this;
    calendarSignData[date] = date;
    calendarSignDay = calendarSignDay + 1;
    wx.setStorageSync("calendarSignData", calendarSignData);
    wx.setStorageSync("calendarSignDay", calendarSignDay);

    var vdata = {
      openId: app.globalData.UserInfo.WeiXinOpenId
    }

    $.xsr($.makeUrl(userapi.signIn,vdata),
      function (e) {
        if(e.errcode==0){
          that.setData({
            calendarSignData: calendarSignData,
            calendarSignDay: calendarSignDay
          })

          wx.showToast({
            title: '签到成功',
            icon: 'success',
            duration: 2000
          })

        }
      })
  },

  onLoad: function () {
    var that =this;
    var mydate = new Date();
    var year = mydate.getFullYear();
    var month = mydate.getMonth() + 1;

    date = mydate.getDate();//几号

    var day = mydate.getDay();//星期几

    var nbsp = 7 - ((date - day) % 7);

    var monthDaySize;

    if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
      monthDaySize = 31;
    } else if (month == 4 || month == 6 || month == 9 || month == 11) {
      monthDaySize = 30;
    } else if (month == 2) {
      // 计算是否是闰年,如果是二月份则是29天
      if ((year - 2000) % 4 == 0) {
        monthDaySize = 29;
      } else {
        monthDaySize = 28;
      }
    };

    var vdata = {
      openId: app.globalData.UserInfo.WeiXinOpenId
    }

    $.xsr($.makeUrl(userapi.querySigninData, vdata),

      function (e) {

        if (e.errcode == 0) {

          that.setData({
            monthDaySize: monthDaySize,
            calendarSignData: e.dataList.signData,
            calendarSignDay: e.dataList.continueDays
          })
          wx.setStorageSync("calendarSignData", e.dataList.signData);
        }
      })

    // 判断是否签到过
    if (wx.getStorageSync("calendarSignData") == null || wx.getStorageSync("calendarSignData") == '') {
      wx.setStorageSync("calendarSignData", new Array(monthDaySize));
    };

    if (wx.getStorageSync("calendarSignDay") == null || wx.getStorageSync("calendarSignDay") == '') {
      wx.setStorageSync("calendarSignDay", 0);
    }

    this.setData({
      year: year,
      month: month,
      nbsp: nbsp,
      monthDaySize: monthDaySize,
      date: date,
      calendarSignData:{},
      calendarSignDay: calendarSignDay
    })
  }

})
