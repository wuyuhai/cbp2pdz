var app = getApp(),
  $ = require("../../utils/util.js"),
  api = require("../../api/categoryAPI.js"),
  listapi = require("../../api/productAPI.js");
Page({
  data: {
    fid: 0,
    Category: [],
    CategoryTwo: [],
    pdlist:[],
    post:{}
  },

  onLoad: function () {
    this.GetCategoryList(),

     this.setData({
        post: {
          orderby:2,
          sort: 2,
          pname: "",
          cid: '441040',
          pageindex:1
        }});
      // this.GetPlist();
  },

  ckCategoryitem: function (e) {
    this.setData({
      fid: e.currentTarget.dataset.id
    }),this.GetCategoryList()
  },

  GetCategoryList: function () {
    
    var e = this,
      t = {
        fatherCategoryId: this.data.fid
      };

    this.setData({
      post: {
        orderby: 2,
        sort: 2,
        pname: "",
        cid: this.data.fid,
        pageindex: 1
      }
    });

    $.xsr($.makeUrl(api.GetCategorylist, t), function (n) {
      t.fatherCategoryId == 0 ? (e.setData({
        Category: n.dataList
      }),
       n.dataList.length >=1 && (e.setData({
        fid: n.dataList[0].id
      }),
       e.GetCategoryList())) :(
        n.dataList.length>0?e.setData({
        CategoryTwo: n.dataList,
        pdlist: ""
          }) : (
            e.GetPlist(), 
          e.setData({
            CategoryTwo:""
          }))
      );
    })
  },

  GetPlist: function (e) {
    var t = this;
    $.xsr($.makeUrl(listapi.GetProductList, this.data.post), function (n) {
      n.dataList.length > 0 ? t.setData({
        pdlist: n.dataList
      }):"";
    })
  }

});