var $ = require("../../utils/util.js");
var amapFile=require("../../utils/amap-wx.js")
Page({
    data: {
        markers: [],
        distance: '',
        cost: '',
        transits: [],
        polyline: [],
        controls: [],
        height:1334,
        width:750,
        endLat: 0,
        endLng: 0,
        startLat:0,
        startLng:0
    },

    bindcontroltap: function(e){
        var that=this;
        e.controlId == 2 ? (wx.openLocation({
            latitude: that.data.endLat,
            longitude: that.data.endLng,
            scale: 28
        })):null;
    },

    onLoad: function (e) {
        var endLat = parseFloat(e.lat);
        var endLng = parseFloat(e.lng);

        // var endLat = '26.42999831802051';
        // var endLng = '106.58604025840759';//天河潭景区

        var that = this;
        wx.getLocation({
            type: 'gcj02',
            success: function (res) {
                console.log(res);
                var startLat = res.latitude;
                var startLng = res.longitude;
                that.setData({
                    startLat: startLat,
                    startLng: startLng,
                    endLat: endLat,
                    endLng: endLng,
                    markers: [{
                        iconPath: "/assets/others.png",
                        id: 1,
                        latitude: startLat,
                        longitude: startLng,
                        width: 30,
                        height: 30,
                        title:'起点'
                    }, {
                        iconPath: "/assets/others.png",
                        id: 2,
                        latitude: endLat,
                        longitude: endLng,
                        width: 30,
                        height: 30,
                        title:'终点'
                  
                    }]
                })

                that.initMap();
            },fail:function(){
                console.log(6666);
            }
        })

        var res = wx.getSystemInfoSync();
        that.setData({
            width: res.windowWidth,
            height: res.windowHeight
        })

        that.setData({
            controls: [{
                id: 2,
                iconPath: '/assets/keymap.png',
                position: {
                    left: that.data.width-70,
                    top: that.data.height-70,
                    width: 50,
                    height: 50,
                    title: "导航"

                },
                clickable: true
            }]
        })
    },
    initMap(){
        var that =this;
        var myAmapFun = new amapFile.AMapWX({ key: '2a9f5cdedad53d7efe2a581da36baa77' });
        myAmapFun.getDrivingRoute({
            origin: that.data.startLng + "," + that.data.startLat,
            destination: that.data.endLng + "," + that.data.endLat,
            success: function (data) {
                var points = [];
                if (data.paths && data.paths[0] && data.paths[0].steps) {
                    var steps = data.paths[0].steps;
                    for (var i = 0; i < steps.length; i++) {
                        var poLen = steps[i].polyline.split(';');
                        for (var j = 0; j < poLen.length; j++) {
                            points.push({
                                longitude: parseFloat(poLen[j].split(',')[0]),
                                latitude: parseFloat(poLen[j].split(',')[1])
                            })
                        }
                    }
                }
                that.setData({
                    polyline: [{
                        points: points,
                        color: "#0091ff",
                        width: 6,
                        dottedLine: true,
                    }]
                });
            },
            fail: function (info) {
                console.log("出错了")
            }
        })
    },
    goToCar: function (e) {
        wx.redirectTo({
            url: '../navigation_car/navigation'
        })
    },
    goToBus: function (e) {
        wx.redirectTo({
            url: '../navigation_bus/navigation'
        })
    },
    goToRide: function (e) {
        wx.redirectTo({
            url: '../navigation_ride/navigation'
        })
    },
    goToWalk: function (e) {
        wx.redirectTo({
            url: '../navigation_walk/navigation'
        })
    }
})