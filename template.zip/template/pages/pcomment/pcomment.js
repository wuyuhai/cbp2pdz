var app = getApp(),
  $ = require("../../utils/util.js"),
  indexapi = require("../../api/indexAPI.js");
Page({
  data: {
    pinjiaList: {},
    star: [],
    content:'',
    ctime:'',
    starMap: [
      '非常差',
      '差',
      '一般',
      '好',
      '非常好',
    ],
    ProductId: 0,
    OrderNum: 0,
    goods_no:0,
    animationData: {}
  },
  onLoad: function (options) {

    console.log(options);

    var that=this;

    var str = JSON.parse(options.items);
    var OrderNum = options.OrderNum
    var ProductId = str.ProductId

    that.setData({
      pinjiaList: str,
      OrderNum: OrderNum,
      ProductId: str.ProductId,
      goods_no: str.goods_no,
      flag: options.flag
    })


    var data = {};
    data.orderId = OrderNum;
    data.productId = ProductId;
    data.ItemId = that.data.goods_no;
    data.openId = app.globalData.UserInfo.WeiXinOpenId;

    if (this.data.flag<1){
      $.xsr($.makeUrl(indexapi.orderPingjiaShow, data),
        function (e) {
          if (e.dataList){
            e.errcode == 0 ? ($.alert("成功！"),
              that.setData({
                star: e.dataList.star,
                content: e.dataList.content,
                ctime: e.dataList.ctime
              }))
              : $.alert(e.errmsg);
          }else{
            that.setData({
              flag:-1
            })
          }
       
        })
    }

  },
  myStarChoose(e) {
    console.log(e.target.dataset.star)
    let star = parseInt(e.target.dataset.star) || 0;
    this.setData({
      star: star,
    })
  },

  formSubmit: function (e) {
    var data = e.detail.value;
    data.orderId = this.data.OrderNum;
    data.productId = this.data.ProductId;
    data.ItemId = this.data.goods_no;
    data.openId = app.globalData.UserInfo.WeiXinOpenId;
    var that=this;
    $.xsr($.makeUrl(indexapi.orderEvaluation, data),
      function (e) {
        e.errcode == 0 ? ($.alert("提交成功！"), 
        setTimeout(function () {
          $.backpage(1,
            function (e) { 
            })
        },1200)):$.alert(e.errmsg);
      })
  }
})