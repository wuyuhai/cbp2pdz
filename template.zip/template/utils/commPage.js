var app = getApp(), 
    $ = require("util.js"),
    notice = require("/notice.js"),
    api = require("../api/indexAPI.js");
module.exports = {
    onReady: function (e) {
        this.audioCtx = wx.createAudioContext('myaudio')
    },
    data: {
        indexArray: [],
        clickpayflag: false,
        platform: '',
        audioSrc: '',
        AudioIcon: '../../assets/top3.png',
        selectval: '',
        options_index: {},
        formItemLength: 0,
        pageId: '',
        imgheights: []
    },
    clicpayphone: function (e) {
        var phones = e.currentTarget.dataset.phones;
        if (phones) {
            wx.makePhoneCall({
                phoneNumber: phones//仅为示例
            })
        } else {
            wx.showToast({
                title: '电话为空',
            })
        }
    },
    clickpay: function () {//播放音乐
        console.log(this);
        if (this.data.clickpayflag) {
            this.setData({
                clickpayflag: !this.data.clickpayflag,
                AudioIcon: '../../assets/top3.png'
            });
            this.audioCtx.play();
        } else {
            this.audioCtx.pause();
            this.setData({
                clickpayflag: !this.data.clickpayflag,
                AudioIcon: '../../assets/top2.png'
            })
        }
    },
    clicktoogle: function (e) {
        var index = e.currentTarget.dataset.index;
        this.data.options_index[index] = e.detail.value;
        this.setData({
            options_index: this.data.options_index
        });
    },
    formSubmit: function (e) {
        var data = e.detail.value;
        var formId = data.formId;
        var dataJson = {};
        for (var i = 0; i < this.data.formItemLength; i++) {
            dataJson[data["key" + i]] = data['value' + i]
        }
        var formData = {
            formId: formId,
            Wechat: this.data.wechat_id,
            openId: app.globalData.UserInfo.WeiXinOpenId,
            data: JSON.stringify(dataJson)
        }
        $.xsr($.makeUrl(api.userInfoSubmitForm, formData),
            function (data) {
                data.errcode == 0 ?$.alert("提交成功！"): $.alert(e.errmsg)
            })
    },
    onLoad: function (e) {

        var that = this;

        that.data.pageId = e.PageId;

        if (that.data.pageId){
          
          that.getIndexData(that.data.pageId);

        }else{

          var matchRes = that.route.match(/menu(\d)$/);

          if (app.globalData.UserInfo) {
            app.getMenuData(app.globalData.menuData);
            that.data.pageId = app.globalData.menuData[matchRes[1]].pageId;
            that.getIndexData(that.data.pageId);
          } else {
            app.GetUserInfo(function () {
              app.getMenuData(app.globalData.menuData);
              that.data.pageId = app.globalData.menuData[matchRes[1]].pageId;
              that.getIndexData(that.data.pageId);
            }, e.uid, e.sid);
            notice.addNotification("RefreshProduct", that.RefreshProduct, that);
          }
        }
    }, 
    onShareAppMessage: function () {
      var pages = getCurrentPages();
      var currentPage = pages[pages.length - 1]
      var url = currentPage.route
      var PageId = currentPage.options ? currentPage.options.PageId : '';
      return {
        title: this.data.onsharname,
        path: url+"?PageId=" + PageId
      }
    },

    getIndexData: function (pageId) {
        var that = this;
        var vdata = {
            PageId: pageId,
            openId: app.globalData.UserInfo.WeiXinOpenId
        };
        $.xsr($.makeUrl(api.GetIndexData, vdata),
            function (res) {
                var formItem = 0;
                console.log(res.dataList);
                var _data = res.dataList.indexArray;
                for (var i = 0; i < _data.length; i++) {
                    if (_data[i].name == 'form') {
                        for (var j = 0; j < _data[i].dataList.length; j++) {
                            var formItems = JSON.parse(_data[i].dataList[j].formItems)
                            _data[i].dataList[j].formItems = formItems;
                        }
                        formItem = formItems.length
                    }
                }
                that.setData({
                    indexArray: _data,
                    formItemLength: formItem ? formItem : 0,
                    onsharname: res.dataList.ShopName
                }),
                wx.setNavigationBarTitle({
                    title: res.dataList.ShopName
                })
            })
    },

    initData: function () {
        // var that = this;
        // if (app.globalData.VendorInfo) {
        //     wx.setNavigationBarTitle({
        //         title: app.globalData.VendorInfo.ShopName
        //     })
        // }
    },

    imageLoad: function (e) {
      //获取图片真实宽度
      var imgwidth = e.detail.width,
        imgheight = e.detail.height,
        //宽高比
        ratio = imgwidth / imgheight;
      // console.log(imgwidth, imgheight)
      //计算的高度值
      var viewHeight = 750 / ratio;
      var imgheight = viewHeight
      var imgheights = this.data.imgheights
      //把每一张图片的高度记录到数组里
      imgheights.push(imgheight)
      this.setData({
        imgheights: imgheights
      })
    }, 
    
    onHide(){
      app.DataStatistic(0);
    },
    onShow() {
      this.audioCtx = wx.createAudioContext('myaudio');
      this.audioCtx.play();
    }
}