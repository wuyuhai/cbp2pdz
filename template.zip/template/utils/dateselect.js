function calendar() {

  var date = new Date()
  var years = [];
  var months = [];
  var days = [];
  var hs = [];
  var ms=[];

  var dateDays = getCountDays();
  for (let i = 2018; i <= date.getFullYear(); i++) {
    years.push(i)
  }

  for (let i = 1; i <= 12; i++) {
    months.push(i)
  }

  for (let i = 1; i <= dateDays; i++) {
    i<10?i="0"+i:i
    days.push(i)
  }

  for (let i = 1; i <= 24; i++) {
    i < 10 ? i = "0" + i : i
    hs.push(i)
  }

  for (let i = 0; i <=3; i++) {
    i == 0 ? ms.push("00") : ms.push(i * 15)
    
  }
  
  var data = {
    years: years,
    year: date.getFullYear(),
    months: months,
    month: date.getMonth() + 1,
    days: days,
    day: date.getDate()+1,
    hs: hs,
    h: "09",
    ms: ms,
    m: "00",
    value: [2018, this.month, this.day, this.h,0]
  }
  return data;
}

function getCountDays () {
  var curDate = new Date();
  var curMonth = curDate.getMonth();
  curDate.setMonth(curMonth+1);
  /* 将日期设置为0, */
  curDate.setDate(0);
  /* 返回当月的天数 */
  return curDate.getDate();
}

module.exports = {
  calendar: calendar
}