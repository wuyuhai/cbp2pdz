var cf = require("../config.js");
module.exports = {
    AddCart: {
        url: cf.config.configUrl + "shoppingcartWebService/AddShoppingCart.html",
        post: {
            wid: cf.config.wid,
            openId: "?",
            proId: "?",
            proName: "?",
            Amount: "?",
            SKU_Id: "?"
        }
    },
    GetCartList: {
        url: cf.config.configUrl + "shoppingcartWebService/GetCartList.html",
        post: {
            wid: cf.config.wid,
            openId: "?",
        }
    },
    CKCartItem: {
        url: cf.config.configUrl + "shoppingcartWebService/CKCartItem.html",
        post: {
            wid: cf.config.wid,
            openId: "?",
            CID: "?",
            IsCK: "?"
        }
    },
    SetSetCartNum: {
        url: cf.config.configUrl + "shoppingcartWebService/SetCartNumber.html",
        post: {
            wid: cf.config.wid,
            openId: "?",
            CID: "?",
            Num: "?"
        }
    },
    GoSettlement: {
        url: cf.config.configUrl + "shoppingcartWebService/AddOrderInformation.html",
        post: {
            wid: cf.config.wid,
            openId: "?",
            couponItemId: "?",
            IsUseCoupon: "?",
            addressId: "?",
            ShoppingCartList: "?"
        }
    },
    DelCartItem: {
        url: cf.config.configUrl + "shoppingcartWebService/DeleteShoppingCart.html",
        post: {
            wid: cf.config.wid,
            SptrId: "?"
        }
    },

    GroupbuyGetCartInfo: {
       url: cf.config.configUrl + "shoppingcartWebService/GroupbuyGetCartInfo.html",
      post: {
        wid: cf.config.wid,
        openId: "?",
        groupbuyId:"?"
      }
    },
     GroupbuyAddOrderDetail: {
      url: cf.config.configUrl + "shoppingcartWebService/GroupbuyAddOrderDetail.html",
      post: {
        wid: cf.config.wid,
        openId: "?",
        groupbuyId:"?",
        addressId:"?",
        ShoppingCartList:"?"
      }
    }
    
};