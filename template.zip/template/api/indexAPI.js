var cf = require("../config.js");
module.exports = {
    GetShopInfo: {
        url: cf.config.configUrl + "shopWebService/GetShopInfo.html",
        postData: {
            wid: cf.config.wid
        }
    },
    AddNewUserAndGetShopInfo: {
        url: cf.config.configUrl + "userWebService/AddNewUserAndGetShopInfo.html",
        post: {
            wid: cf.config.wid,
            NickName: "?",
            sex: "?",
            photo: "?",
            WXCountry: "?",
            WXCity: "?",
            code: "?",
            WXProvince: "?",
            Uid: "?",
            storeId: "?"
        }
    },
    GetIndexData: {
        url: cf.config.configUrl + "indexWebService/GetIndexData.html",
        post: {
            wid: cf.config.wid,
            PageId: "?",
            openId:"?"
        }
    },
    userInfoSubmitForm: {
        url: cf.config.configUrl + "userWebService/AddFormData.html",
        post: {
            wid: cf.config.wid,
            openId: "?",
            data: "?",
            formId: "?"
        }
    },
    orderEvaluation: {
      url: cf.config.configUrl + "userWebService/ProductEvaluation.html",
      post: {
        wid: cf.config.wid,
        openId: "?",
        orderId: "?",
        productId: "?",
        ItemId: "?",
        star: "?",
        content: ""
      }
    },
    orderPingjiaShow: {
      url: cf.config.configUrl + "proudctWebService/GetProductEvaluationList.html",
      post: {
        wid: cf.config.wid,
        openId: "?",
        orderId: "?",
        productId: "?",
        ItemId: "?"
      }
    },
    AddLeaveVisitLog:{
      url: cf.config.configUrl + "indexWebService/AddLeaveVisitLog.html",
      post: {
        wid: cf.config.wid,
        openId: "?",
        page_url:"?",
        page_id:"?",
        data_id:"?",
        showLoading:"?"
      }
    }
};