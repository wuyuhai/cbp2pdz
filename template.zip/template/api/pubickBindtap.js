function  Payaudio() {
    var payflage=false;
    console.log(132465987)

}