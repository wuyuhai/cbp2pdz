var $ = require("utils/util.js"),
  api = require("api/indexAPI.js");
import wxValidate from './utils/WxValidate.js'

App({
  onLaunch: function () { },

  DataStatistic(dataId) {//数据统计
    var pages = getCurrentPages(),
      currentPage = pages[pages.length - 1],
      url = currentPage.route,
      pagesId = currentPage.options ? currentPage.options : 0,
      dataId = dataId;
    var vdata = {
      page_url: url,
      page_id: pagesId,
      data_id: dataId,
      openId: this.globalData.UserInfo.WeiXinOpenId,
      showLoading: "false"
    }
    console.log(this.globalData.UserInfo.WeiXinOpenId);
    $.xsr($.makeUrl(api.AddLeaveVisitLog, vdata),
      function (res) {
      });
  },

  GetUserInfo: function (e, t, n) {//获取用户信息并存到globalData.UserInfo

    var that = this;
    wx.login({
      success: function (i) {
        var u = {
          code: i.code,
          Uid: t || 0,
          storeId: n || 0
        };
        $.xsr($.makeUrl(api.AddNewUserAndGetShopInfo, u),
          function (res) {
            that.globalData.VendorInfo = res.dataList.ShopInfo,
              that.globalData.UserInfo = res.dataList.UserInfo,
              that.globalData.menuData = res.dataList.menuData
            e && e();
            console.log(that.globalData.UserInfo)//打印用户信息
          })
      },
      complete: function (e) {
        console.log(e)
      }
    })
  },
  globalData: {
    UserInfo: null,
    VendorInfo: null,
    menuData: null
  },
  getMenuData: function (menuData) {//自定义tabbar
    console.log(menuData)
    if (menuData) {
      var pages = getCurrentPages();
      var currentPage = pages[pages.length - 1]
      var url = currentPage.route
      var PageId = currentPage.options.PageId || '';
      console.log(currentPage.options)
      var hasMenu = false;

      var odurl = "/" + url + "?PageId=" + PageId;

      for (var i = 0; i < menuData.length; i++) {
        if (menuData[i].iconPath.substr(0, 1) == '/') {
          var iconPathrul = menuData[i].iconPath.substr(1);
        }
        if (menuData[i].selectedIconPath.substr(0, 1) == '/') {
          var selectedIconpathul = menuData[i].selectedIconPath.substr(1);
        }

        wx.setTabBarItem({
          index: i,
          text: menuData[i].text,
          iconPath: iconPathrul,
          selectedIconPath: selectedIconpathul
        })
        if (menuData[i].pagePath == odurl || menuData[i].pagePath == "/" + url) {
          menuData[i]["selected"] = true;
          hasMenu = true;
        } else {
          menuData[i]["selected"] = false;
        }
      }
    }
    
    if (url) url.indexOf("pages/index/index") !== false ? hasMenu = true : ""
    return hasMenu ? menuData : false;
  },

  data: {
    hasMenu: false
  },

  wuiAlert: function (title, content, ok, clear) {
    var clearflag = false;
    $.isNull(clear) ? clearflag = false : clearflag = true;
    wx.showModal({
      title: title,
      content: content,
      confirmText: ok,
      cancelText: clear,
      showCancel: clearflag,
      success: function (res) {
        console.log(res);
        if (res.confirm) {
          return true;
        } else {
          return false;
        }
      }
    });
  }
});