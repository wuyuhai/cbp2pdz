var cf = require("../config.js");
module.exports = {
    GetShopInfo: {
        url: cf.config.configUrl + "shopcyWebService/GetShopInfo.html",
        postData: {wid: cf.config.wid}
    },
    AddNewUserAndGetShopInfo: {
        url: cf.config.configUrl + "userWebService/AddNewUserAndGetShopInfo.html",
        post: {
            wid: cf.config.wid,
            NickName: "?",
            sex: "?",
            photo: "?",
            WXCountry: "?",
            WXCity: "?",
            code: "?",
            WXProvince: "?",
            Uid: "?",
            storeId: "?"
        }
    },
    GetIndexData: {
        url: cf.config.configUrl + "indexcyWebService/GetIndexData.html",
        post: {wid: cf.config.wid, PageId: "?"}
    }
};