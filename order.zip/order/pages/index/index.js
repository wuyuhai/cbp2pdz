var app = getApp(), $ = require("../../utils/util.js"), api = require("../../api/categoryAPI.js"), papi = require('../../api/productAPI.js'), capi = require("../../api/cartAPI.js");
Page({
  data: { fid: 0, Category: [], CategoryTwo: [], ShopInfo: [], ProductList: [], Aprice: 0 },
  onLoad: function () {
    var that = this;

    app.GetUserInfo(function () {
      that.GetCategoryList()
      that.setData({ ShopInfo: app.globalData.VendorInfo });
    })
  }, ckCategoryitem: function (e) {
    this.setData({ fid: e.currentTarget.dataset.id, ProductList: null }), this.GetCategoryList()
  }, GetCategoryList: function () {
    var e = this, t = { fatherCategoryId: this.data.fid };
    $.xsr($.makeUrl(api.GetCategorylist, t), function (n) {
      console.log(n), t.fatherCategoryId == 0 ? (e.setData({ Category: n.dataList }), n.dataList.length > 0 && (e.setData({ fid: n.dataList[0].id }), e.GetCategoryList())) : e.setData({ CategoryTwo: n.dataList })
    })
  },
  add: function (e) {
    var t = {
      btntype: 1,
      numval: e.currentTarget.dataset.num,
      index: e.currentTarget.dataset.index
    };
    this.unifiedNum(t)
  },
  sub: function (e) {
    var t = {
      btntype: 2,
      numval: e.currentTarget.dataset.num,
      index: e.currentTarget.dataset.index
    };
    this.unifiedNum(t)
  },
  unifiedNum: function (e) {
    var t = { value: parseInt(e.numval) }, pro = this.data.ProductList;
    e.btntype == 1 && (t.value = t.value + 1), e.btntype == 2 && (t.value = t.value - 1), t.value < 0 && (t.value = 0);
    pro[e.index]['count'] = t.value;
    
    this.setData({ Aprice: this.sum(), ProductList: pro });
   /*
    var n = {openid: app.globalData.UserInfo.WeiXinOpenId,cid:e.cid,num:t.value}, r = this;
    $.xsr($.makeUrl(capi.SetSetCartNum,n),function(e){
          if(e.errcode == 0){
           //刷新
          }
    })
      */
  },
  ckProductitem: function (e) {
    var t = {
      cid: e.currentTarget.dataset.id,
      orderby: 1,
      sort: 1,
      isnew: 1,
      pageindex: 1
    }, that = this;
    $.xsr($.makeUrl(papi.GetProductList, t), function (e) {
      if (e.errcode == 0) {
        that.setData({ ProductList: e.dataList })
      }
    });
  },
  delAll: function () {
    var pro = this.data.ProductList;
    for (var i = 0; i < pro.length; i++) {
      pro[i].count = 0;
    }
    this.setData({
      Aprice: 0,
      ProductList: pro
    })
  },
  sum: function () {
    var pro = this.data.ProductList, price = 0;
    for (var i = 0; i < pro.length; i++) {
      price = price + pro[i].count * pro[i].SalePrice;
    }
    return price;
  },
  submitorder: function () {
    //尚未添加到购物车中
    var pro = this.data.ProductList;
    for (var i = 0; i < pro.length; i++) {
      if (pro[i].count > 0) {
        var t = {
          proId: pro[i].id,
          proName: pro[i].SalesName,
          Amount: pro[i].count,
          SKU_Id: pro[i].SKU_Id,
          openId: app.globalData.UserInfo.WeiXinOpenId
        };
        $.xsr($.makeUrl(capi.AddCart, t), function (r) {
          if (r.errcode == 0) {
            console.dir(r);
          }
        });
      }
    }
    wx.navigateTo({ url: "/pages/ordersubmit/ordersubmit" });
  }
});