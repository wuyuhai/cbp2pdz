var $ = require("utils/util.js"), api = require("api/indexAPI.js");
App({
    onLaunch: function () {
    }, GetUserInfo: function (e, t, n) {
        var that = this;
        wx.login({
            success: function (i) {
                wx.getUserInfo({
                    success: function (s) {
                        var o = s.userInfo, u = {
                            NickName: o.nickName,
                            sex: o.gender,
                            photo: o.avatarUrl,
                            WXCountry: o.country,
                            WXCity: o.city,
                            code: i.code,
                            WXProvince: o.province,
                            Uid: t || 0,
                            storeId: n || 0
                        };
                        console.log(u), $.xsr($.makeUrl(api.AddNewUserAndGetShopInfo, u), function (res) {
                            console.log(res), that.globalData.VendorInfo = res.dataList.ShopInfo, that.globalData.UserInfo = res.dataList.UserInfo, e && e()
                        })
                    }
                })
            }
        })
    }, globalData: {UserInfo: null, VendorInfo: null}
});