var app = getApp(), $ = require("util.js"),
    api = require("../api/indexAPI.js");
module.exports = {
    onReady: function (e) {
        this.audioCtx = wx.createAudioContext('myaudio')
    },
    data: {
        indexArray: [],
        clickpayflag: false,
        platform: '',
        audioSrc: '',
        AudioIcon: '../../assets/top3.png',
        selectval: '',
        options_index: {},
        formItemLength: 0,
        pageId: ''
    },
    clicpayphone: function (e) {
        var phones = e.currentTarget.dataset.phones;
        if (phones) {
            wx.makePhoneCall({
                phoneNumber: phones//仅为示例
            })
        } else {
            wx.showToast({
                title: '电话为空',
            })
        }
    },
    clickpay: function () {//播放音乐
        console.log(this);
        if (this.data.clickpayflag) {
            this.setData({
                clickpayflag: !this.data.clickpayflag,
                AudioIcon: '../../assets/top3.png'
            });
            this.audioCtx.play();
        } else {
            this.audioCtx.pause();
            this.setData({
                clickpayflag: !this.data.clickpayflag,
                AudioIcon: '../../assets/top2.png'
            })
        }
        console.log(this.data.AudioIcon);
    },
    clicktoogle: function (e) {
        var index = e.currentTarget.dataset.index;
        this.data.options_index[index] = e.detail.value;
        this.setData({
            options_index: this.data.options_index
        });
    },
    formSubmit: function (e) {
        var data = e.detail.value;
        var formId = data.formId;
        var dataJson = {};
        for (var i = 0; i < this.data.formItemLength; i++) {
            dataJson[data["key" + i]] = data['value' + i]
        }
        var formData = {
            formId: formId,
            Wechat: this.data.wechat_id,
            openId: app.globalData.UserInfo.WeiXinOpenId,
            data: JSON.stringify(dataJson)
        }

        $.xsr($.makeUrl(api.userInfoSubmitForm, formData),
            function (data) {
                data.errcode == 0 ? ($.alert("提交成功！"), setTimeout(function () {
                        $.backpage(1,
                            function () {
                                $.alert("提交成功！")
                            })
                    },
                    1e3)) : $.alert(e.errmsg)
            })
    },

    onLoad: function (e) {
        var that = this;
        var matchRes = that.route.match(/menu(\d)$/);
        that.data.pageId = e.PageId || 0;
        if (that.data.pageId) {
            that.getIndexData(that.data.pageId);
        } else if (!that.data.pageId && matchRes[1] && typeof (wx.getExtConfig) == 'function') {
            wx.getExtConfig({
                success: function (resExt) {
                    var extMenus = resExt.extConfig.extMenus;//第三方平台自定义的数据
                    if (extMenus[matchRes[1]]) {
                        that.data.pageId = extMenus[matchRes[1]];
                        if (that.data.pageId) {
                            that.getIndexData(that.data.pageId);
                        }
                    }
                }
            })
        }
    },

    getIndexData: function (pageId) {
        var that = this;
        that.initData();
        var vdata = {
            PageId: pageId
        };
        $.xsr($.makeUrl(api.GetIndexData, vdata),
            function (res) {
                var formItem = 0;
                console.log(res.dataList);
                var _data = res.dataList.indexArray;
                for (var i = 0; i < _data.length; i++) {
                    if (_data[i].name == 'form') {
                        for (var j = 0; j < _data[i].dataList.length; j++) {
                            var formItems = JSON.parse(_data[i].dataList[j].formItems)
                            _data[i].dataList[j].formItems = formItems;
                        }
                        formItem = formItems.length
                    }
                }
                that.setData({
                    indexArray: _data,
                    formItemLength: formItem ? formItem : 0
                }),

                    wx.setNavigationBarTitle({
                        title: res.dataList.ShopName
                    })
            })
    },

    initData: function () {
        var that = this;
        if (app.globalData.VendorInfo) {
            wx.setNavigationBarTitle({
                title: app.globalData.VendorInfo.ShopName
            })
        }
    }
}